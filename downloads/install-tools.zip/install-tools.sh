#!/bin/bash
set -Eeuo pipefail

# =========================================================
# SVWS-Tools installieren und konfigurieren
# =========================================================

TOOLS_URL="https://github.com/TheoRichter/SVWS-Tools/raw/refs/heads/main/downloads/tools.zip"

# Ziel für die Tools
APP_DIR="/opt/app/svws"

# Konfiguration und Backup ausschließlich hier
CONFIG_DIR="/etc/app/svws/conf"
CONFIG_FILE="$CONFIG_DIR/svwsconfig.json"
BACKUP_FILE="$CONFIG_DIR/svwsconfig.json.bak.$(date +%Y%m%d-%H%M%S)"

ZIP_FILE="/tmp/svws-tools.zip"
SERVICE="svws.service"
BROWSER_URL="https://localhost:8443/app/start"

echo "================================================="
echo " SVWS-Tools Installation"
echo "================================================="

# 1. Root-Rechte prüfen
if [ "$EUID" -ne 0 ]; then
    echo "FEHLER: Bitte als root oder mit sudo starten."
    exit 1
fi

# 2. Voraussetzungen prüfen
for CMD in curl unzip python3 systemctl; do
    if ! command -v "$CMD" >/dev/null 2>&1; then
        echo "FEHLER: Programm '$CMD' fehlt."
        echo "Installation: apt install curl unzip python3"
        exit 1
    fi
done

# 3. Verzeichnisse und Konfigurationsdatei prüfen
if [ ! -d "$APP_DIR" ]; then
    echo "FEHLER: Verzeichnis nicht gefunden: $APP_DIR"
    exit 1
fi

if [ ! -d "$CONFIG_DIR" ]; then
    echo "FEHLER: Konfigurationsverzeichnis nicht gefunden:"
    echo "$CONFIG_DIR"
    exit 1
fi

if [ ! -f "$CONFIG_FILE" ]; then
    echo "FEHLER: Konfigurationsdatei nicht gefunden:"
    echo "$CONFIG_FILE"
    echo "Es wird keine neue Konfigurationsdatei angelegt."
    exit 1
fi

# 4. Backup im Konfigurationsverzeichnis erstellen
cp -a "$CONFIG_FILE" "$BACKUP_FILE"

echo "Backup erstellt:"
echo "$BACKUP_FILE"

# 5. ZIP herunterladen
echo
echo "Lade tools.zip herunter ..."

curl -fL --retry 3 "$TOOLS_URL" -o "$ZIP_FILE"

# 6. ZIP prüfen und direkt nach APP_DIR entpacken
echo
echo "Prüfe ZIP-Datei ..."
unzip -tq "$ZIP_FILE"

echo "Entpacke Tools nach $APP_DIR ..."
unzip -oq "$ZIP_FILE" -d "$APP_DIR"

# 7. Ausschließlich die Konfiguration in CONFIG_FILE bearbeiten
echo
echo "Bearbeite: $CONFIG_FILE"

python3 - "$CONFIG_FILE" <<'PYTHON'
import json
import sys
from pathlib import Path

config_file = Path(sys.argv[1])

# Sicherheitsprüfung: nur der gewünschte Pfad ist zulässig
expected = Path("/etc/app/svws/conf/svwsconfig.json")

if config_file != expected:
    print(f"FEHLER: Unerwarteter Konfigurationspfad: {config_file}")
    sys.exit(1)

if not config_file.is_file():
    print(f"FEHLER: Datei nicht gefunden: {config_file}")
    sys.exit(1)

try:
    config = json.loads(config_file.read_text(encoding="utf-8"))
except Exception as exc:
    print(f"FEHLER beim Lesen der JSON-Datei: {exc}")
    sys.exit(1)

if not isinstance(config, dict):
    print("FEHLER: Die Konfiguration ist kein JSON-Objekt.")
    sys.exit(1)

if "AppsPath" in config:
    config["AppsPath"] = "../tools"
    print('AppsPath auf "../tools" gesetzt.')
else:
    if "AdminClientPath" not in config:
        print("FEHLER: AdminClientPath fehlt.")
        sys.exit(1)

    updated = {}
    for key, value in config.items():
        updated[key] = value
        if key == "AdminClientPath":
            updated["AppsPath"] = "../tools"

    config = updated
    print('AppsPath nach AdminClientPath eingefügt.')

keys = list(config.keys())

if (
    "LoggingEnabled" in keys
    and keys.index("AppsPath") > keys.index("LoggingEnabled")
):
    print("FEHLER: AppsPath steht hinter LoggingEnabled.")
    sys.exit(1)

# Temporäre Datei im selben Verzeichnis schreiben
temp_file = config_file.with_name("svwsconfig.json.tmp")

try:
    temp_file.write_text(
        json.dumps(config, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8"
    )

    # JSON vor dem Ersetzen erneut prüfen
    json.loads(temp_file.read_text(encoding="utf-8"))

    # Berechtigungen der bisherigen Datei übernehmen
    import os
    stat = config_file.stat()
    os.chmod(temp_file, stat.st_mode)
    os.chown(temp_file, stat.st_uid, stat.st_gid)

    temp_file.replace(config_file)

except Exception as exc:
    temp_file.unlink(missing_ok=True)
    print(f"FEHLER beim Speichern: {exc}")
    sys.exit(1)

print(f"Konfiguration erfolgreich gespeichert: {config_file}")
PYTHON

# 8. Kontrollieren, dass keine Konfiguration im APP_DIR geändert wurde
echo
echo "Verwendete Konfigurationsdatei:"
readlink -f "$CONFIG_FILE"

# 9. SVWS-Dienst neu starten
echo
echo "Starte $SERVICE neu ..."
systemctl restart "$SERVICE"

sleep 3

if systemctl is-active --quiet "$SERVICE"; then
    echo "SVWS-Dienst läuft."
else
    echo "FEHLER: SVWS-Dienst läuft nicht."
    systemctl --no-pager --full status "$SERVICE" || true
    echo "Backup liegt unter: $BACKUP_FILE"
    exit 1
fi

# 10. Browser direkt auf Debian öffnen
echo
echo "Öffne SVWS im Debian-Browser ..."

if [ -n "${DISPLAY:-}" ] || [ -n "${WAYLAND_DISPLAY:-}" ]; then
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$BROWSER_URL" >/dev/null 2>&1 &
    elif command -v firefox-esr >/dev/null 2>&1; then
        firefox-esr "$BROWSER_URL" >/dev/null 2>&1 &
    elif command -v firefox >/dev/null 2>&1; then
        firefox "$BROWSER_URL" >/dev/null 2>&1 &
    else
        echo "Kein Browser gefunden. Installiere: apt install firefox-esr xdg-utils"
        echo "URL: $BROWSER_URL"
    fi
else
    echo "Keine grafische Sitzung erkannt."
    echo "Bitte im Debian-Browser öffnen: $BROWSER_URL"
fi

# 11. Aufräumen
rm -f "$ZIP_FILE"

echo
echo "================================================="
echo " Installation abgeschlossen!"
echo "================================================="
echo "Tools:          $APP_DIR"
echo "Konfiguration:  $CONFIG_FILE"
echo "Backup:         $BACKUP_FILE"
echo "Dienst:         $SERVICE"
echo "Browser:        $BROWSER_URL"
echo "================================================="