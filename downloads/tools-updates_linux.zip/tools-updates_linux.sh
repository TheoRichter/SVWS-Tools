#!/bin/bash
set -Eeuo pipefail

# ==========================================
# SVWS-Tools herunterladen und installieren
# Debian 13
# ==========================================

echo
echo "=========================================="
echo "       SVWS-Tools Installation"
echo "=========================================="
echo
echo "1) conference"
echo "2) info"
echo "3) gradhub"
echo "4) prognos"
echo "5) laufbahn"
echo

read -r -p "Tool eingeben: " TOOL
TOOL="${TOOL,,}"

read -r -p "Versionsnummer eingeben (z.B. 1.0.0): " VERSION

# ==========================================
# Versionsnummer prüfen
# ==========================================

if [[ ! "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+([.-][A-Za-z0-9.-]+)?$ ]]; then
    echo "FEHLER: Ungültige Versionsnummer: $VERSION"
    exit 1
fi

# ==========================================
# Tool konfigurieren
# ==========================================

case "$TOOL" in

    conference)
        REPO="SVWS-Conference"
        ZIP_NAME="svws-conference-${VERSION}-webserver.zip"
        INSTALL_DIR="/opt/app/svws/tools/conference"
        ;;

    info)
        REPO="SVWS-Import"
        ZIP_NAME="SVWS-Import-${VERSION}-webapp.zip"
        INSTALL_DIR="/opt/app/svws/tools/info"
        ;;

    gradhub)
        REPO="SVWS-GradeHub"
        ZIP_NAME="gradehub-${VERSION}-webserver.zip"
        INSTALL_DIR="/opt/app/svws/tools/gradhub"
        ;;

    prognos)
        REPO="SVWS-Prognos"
        ZIP_NAME="svws-prognos-${VERSION}-webserver.zip"
        INSTALL_DIR="/opt/app/svws/tools/prognos"
        ;;

    laufbahn)
        REPO="SVWS-Server"
        ZIP_NAME="SVWS-Laufbahnplanung-${VERSION}.zip"
        INSTALL_DIR="/opt/app/svws/tools/laufbahn"
        ;;

    *)
        echo "FEHLER: Unbekanntes Tool: $TOOL"
        echo "Erlaubt: conference, info, gradhub, prognos, laufbahn"
        exit 1
        ;;
esac

# ==========================================
# Download-URL erstellen
# ==========================================

DOWNLOAD_URL="https://github.com/SVWS-NRW/${REPO}/releases/download/v${VERSION}/${ZIP_NAME}"

# ==========================================
# Voraussetzungen prüfen
# ==========================================

for PROGRAM in curl unzip; do
    if ! command -v "$PROGRAM" >/dev/null 2>&1; then
        echo "FEHLER: $PROGRAM ist nicht installiert."
        echo "Installation mit: apt install curl unzip"
        exit 1
    fi
done

# ==========================================
# Übersicht und Bestätigung
# ==========================================

echo
echo "=========================================="
echo "Tool:        $TOOL"
echo "Version:     $VERSION"
echo "Download:    $DOWNLOAD_URL"
echo "Zielordner:  $INSTALL_DIR"
echo "=========================================="
echo

read -r -p "Installation starten? (j/n): " CONFIRM

if [[ ! "$CONFIRM" =~ ^[jJyY]$ ]]; then
    echo "Installation abgebrochen."
    exit 0
fi

# ==========================================
# Temporäres Download-Verzeichnis
# ==========================================

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

ZIP_FILE="${TEMP_DIR}/${ZIP_NAME}"

# ==========================================
# Download
# ==========================================

echo
echo "Lade Datei herunter ..."

if ! curl -fL --retry 2 --connect-timeout 20 \
    -o "$ZIP_FILE" "$DOWNLOAD_URL"; then
    echo
    echo "FEHLER: Download fehlgeschlagen."
    echo "Bitte Version und Download-Adresse prüfen."
    exit 1
fi

# ==========================================
# ZIP-Datei überprüfen
# ==========================================

if ! unzip -tq "$ZIP_FILE" >/dev/null; then
    echo "FEHLER: Die ZIP-Datei ist beschädigt oder ungültig."
    exit 1
fi

# ==========================================
# Zielverzeichnis erstellen
# ==========================================

mkdir -p "$INSTALL_DIR"

# ==========================================
# ZIP-Datei verschieben
# ==========================================

echo
echo "Verschiebe ZIP-Datei nach:"
echo "$INSTALL_DIR"

mv "$ZIP_FILE" "${INSTALL_DIR}/${ZIP_NAME}"

# ==========================================
# ZIP-Datei entpacken
# ==========================================

echo "Entpacke Dateien ..."

if ! unzip -oq "${INSTALL_DIR}/${ZIP_NAME}" -d "$INSTALL_DIR"; then
    echo "FEHLER: Entpacken fehlgeschlagen."
    echo "Die ZIP-Datei bleibt zur Fehleranalyse erhalten:"
    echo "${INSTALL_DIR}/${ZIP_NAME}"
    exit 1
fi

# ==========================================
# ZIP-Datei löschen
# ==========================================

rm -f "${INSTALL_DIR}/${ZIP_NAME}"

# ==========================================
# Abschlussmeldung
# ==========================================

echo
echo "=========================================="
echo "Installation erfolgreich abgeschlossen!"
echo "=========================================="
echo "Tool:        $TOOL"
echo "Version:     $VERSION"
echo "Verzeichnis: $INSTALL_DIR"
echo "ZIP-Datei:   gelöscht"
echo "=========================================="
