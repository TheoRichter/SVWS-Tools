@echo off
setlocal EnableExtensions DisableDelayedExpansion
title SVWS-Tools installieren
REM ==========================================================================
REM  SVWS-Tools-Installieren.bat  -  Version 2.0  (2026-11-19)
REM
REM  Laedt die SVWS-Tools herunter, prueft sie, installiert sie in den
REM  SVWS-Server-Ordner, traegt "AppsPath" in die svwsconfig.json ein und
REM  startet den SVWS-Dienst neu. Bei einem Fehler wird der vorherige
REM  Zustand automatisch wiederhergestellt.
REM
REM  Aufbau: Hybrid-Datei. Der obere Teil ist Batch und dient nur als
REM  Starter. Ab der Markierungszeile (PS-Marker, siehe unten) folgt das
REM  eigentliche Programm in PowerShell. Der Batch-Teil kopiert diesen
REM  Abschnitt unveraendert in eine temporaere .ps1-Datei und fuehrt sie aus.
REM  Dadurch ist kein Maskieren von Sonderzeichen per echo noetig.
REM
REM  Aufruf:   SVWS-Tools-Installieren.bat           interaktiv
REM            SVWS-Tools-Installieren.bat /quiet    ohne Rueckfragen
REM
REM  Exitcodes: 0 = Erfolg
REM             1 = Fehler, vorheriger Zustand wiederhergestellt
REM             2 = Abbruch durch Benutzer, nichts veraendert
REM             3 = Fehler, Wiederherstellung unvollstaendig (Protokoll!)
REM             4 = Startfehler (keine Adminrechte im Modus /quiet,
REM                 PowerShell-Teil nicht lesbar)
REM
REM  Einstellungen (Download-Adresse, Pruefsumme, Pfade) stehen am Anfang
REM  des PowerShell-Teils im Block "KONFIGURATION".
REM ==========================================================================

set "SVWS_SELF=%~f0"
set "QUIET="
if /i "%~1"=="/quiet" set "QUIET=1"
if /i "%~1"=="-quiet" set "QUIET=1"

REM --- Administratorrechte pruefen, bei Bedarf per UAC neu starten ---------
net session >nul 2>&1
if errorlevel 1 (
    if defined QUIET (
        echo FEHLER: Im Modus /quiet bitte direkt als Administrator starten.
        exit /b 4
    )
    echo Administratorrechte werden angefordert ...
    powershell.exe -NoProfile -Command "Start-Process -FilePath $env:SVWS_SELF -Verb RunAs"
    exit /b 0
)

echo.
echo ==========================================
echo       SVWS-Tools Installation 2.0
echo ==========================================

REM --- PowerShell-Teil in eine temporaere Datei kopieren --------------------
set "SVWS_PS1=%TEMP%\svws-tools-install-%RANDOM%%RANDOM%.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:SVWS_SELF); $m='###'+'PS-START###'; $i=$t.IndexOf($m); if($i -lt 0){exit 1}; [IO.File]::WriteAllText($env:SVWS_PS1, $t.Substring($i), (New-Object Text.UTF8Encoding $true))"
if errorlevel 1 (
    echo FEHLER: Der PowerShell-Teil konnte nicht gelesen werden.
    if not defined QUIET pause
    exit /b 4
)

REM --- PowerShell-Teil ausfuehren --------------------------------------------
set "PSARGS="
if defined QUIET set "PSARGS=-Quiet"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SVWS_PS1%" %PSARGS%
set "RC=%ERRORLEVEL%"
del "%SVWS_PS1%" >nul 2>&1

echo.
if "%RC%"=="0" echo Installation erfolgreich abgeschlossen.
if "%RC%"=="1" echo FEHLER: Installation fehlgeschlagen. Der vorherige Zustand wurde wiederhergestellt.
if "%RC%"=="2" echo Installation abgebrochen. Es wurde nichts veraendert.
if "%RC%"=="3" echo FEHLER: Wiederherstellung unvollstaendig. Bitte das Protokoll pruefen!
if %RC% GTR 3 echo FEHLER: Unerwarteter Exitcode %RC%.
if not defined QUIET pause
exit /b %RC%

###PS-START###
# ==========================================================================
#  PowerShell-Teil von SVWS-Tools-Installieren.bat (Version 2.0)
#  Wird von der Batch-Huelle in eine temporaere .ps1 kopiert und mit
#  Windows PowerShell 5.1 ausgefuehrt. Nur ASCII-Zeichen verwenden!
# ==========================================================================
param(
    [switch]$Quiet
)

# ----------------------------- KONFIGURATION ------------------------------
$Base              = 'C:\ProgramData\SVWS-Server'
$ConfigFile        = Join-Path $Base 'res\svwsconfig.json'
$ServiceName       = 'SVWS-Java-Service'
$ToolsDirName      = 'tools'
$DownloadUrl       = 'https://github.com/TheoRichter/SVWS-Tools/raw/refs/heads/main/downloads/tools.zip'
# SHA-256 der freigegebenen tools.zip (64 Hex-Zeichen). Leer = die Pruefsumme
# wird nur angezeigt und muss interaktiv bestaetigt werden; mit /quiet wird
# dann nicht installiert.
$ExpectedSha256    = ''
$KeepOldTools      = 2      # Anzahl alter tools-Ordner, die erhalten bleiben
$KeepConfigBackups = 5      # Anzahl alter svwsconfig-Sicherungen
$ServiceTimeoutSec = 60     # Wartezeit auf Dienststatus (Sekunden)
$PortTimeoutSec    = 120    # Wartezeit, bis der Server erreichbar ist
$LogDir            = Join-Path $Base 'install-logs'
# --------------------------------------------------------------------------

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'   # beschleunigt Invoke-WebRequest
Set-StrictMode -Version 2.0

$stamp    = Get-Date -Format 'yyyy-MM-dd_HHmmss'
$work     = Join-Path $env:TEMP "svws-tools-$stamp"
$zip      = Join-Path $work 'tools.zip'
$stage    = Join-Path $work 'entpackt'
$toolsDir = Join-Path $Base $ToolsDirName
$oldTools = Join-Path $Base "$ToolsDirName.alt-$stamp"
$backup   = "$ConfigFile.$stamp.bak"

# Merkt sich, was bereits veraendert wurde (Grundlage fuer den Rollback)
$state = @{
    WasRunning     = $false
    ServiceStopped = $false
    OldToolsMoved  = $false
    NewToolsPlaced = $false
    ConfigChanged  = $false
}

# ------------------------------ FUNKTIONEN --------------------------------
function Write-Step([string]$Text) {
    Write-Host ''
    Write-Host "==> $Text" -ForegroundColor Cyan
}

function Write-Info([string]$Text) {
    Write-Host "    $Text"
}

function Confirm-Action([string]$Question) {
    $answer = Read-Host "$Question [j/N]"
    return ($answer -match '^\s*(j|ja|y|yes)\s*$')
}

function Stop-Cancelled([string]$Text) {
    throw (New-Object System.OperationCanceledException $Text)
}

function Read-TextFile([string]$Path) {
    # Liest UTF-8 mit oder ohne BOM; ein BOM wird entfernt
    return [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8)
}

function Write-TextFile([string]$Path, [string]$Text) {
    # UTF-8 ohne BOM - der Java-Server vertraegt kein BOM
    [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding $false))
}

function ConvertTo-JsonString([string]$Value) {
    # Maskiert Backslash und Anfuehrungszeichen fuer einen JSON-String
    return '"' + ($Value -replace '\\', '\\' -replace '"', '\"') + '"'
}

function Set-AppsPath([string]$Text, [string]$JsonLiteral) {
    # Setzt "AppsPath" textuell, damit Formatierung und Reihenfolge der
    # Konfiguration erhalten bleiben.
    $nl = if ($Text.Contains("`r`n")) { "`r`n" } else { "`n" }

    # Fall 1: Schluessel vorhanden (Wert ist String oder null) -> Wert ersetzen
    $keyRx = New-Object regex '(?m)^([ \t]*"AppsPath"[ \t]*:[ \t]*)("(?:[^"\\]|\\.)*"|null)'
    if ($keyRx.IsMatch($Text)) {
        $evaluator = [Text.RegularExpressions.MatchEvaluator] {
            param($m) $m.Groups[1].Value + $JsonLiteral
        }
        return $keyRx.Replace($Text, $evaluator, 1)
    }

    # Fall 2: Schluessel fehlt -> neue Zeile VOR "AdminClientPath" einfuegen.
    # Danach folgt immer noch ein Eintrag, das Komma ist also stets korrekt.
    $adminRx = New-Object regex '(?m)^([ \t]*)"AdminClientPath"[ \t]*:'
    $m = $adminRx.Match($Text)
    if (-not $m.Success) {
        throw 'Weder "AppsPath" noch "AdminClientPath" in svwsconfig.json gefunden.'
    }
    $line = $m.Groups[1].Value + '"AppsPath" : ' + $JsonLiteral + ',' + $nl
    return $Text.Insert($m.Index, $line)
}

function Test-ConfigText([string]$Text, [string]$ExpectedPath) {
    # Strenger als ConvertFrom-Json: nachgestellte Kommas sind verboten,
    # weil der Java-Server sie ablehnt.
    if ([regex]::IsMatch($Text, ',\s*[}\]]')) {
        throw 'Die geaenderte svwsconfig.json enthaelt ein nachgestelltes Komma.'
    }
    $obj = $Text | ConvertFrom-Json
    if ($obj.AppsPath -ne $ExpectedPath) {
        throw "AppsPath hat nach der Aenderung den unerwarteten Wert '$($obj.AppsPath)'."
    }
}

function Get-HttpsPort($ConfigObject) {
    $p = $ConfigObject.PSObject.Properties['PortHTTPS']
    if ($p -and $p.Value) { return [int]$p.Value }
    return 443
}

function Wait-TcpPort([int]$Port, [int]$TimeoutSec) {
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        $client = New-Object Net.Sockets.TcpClient
        try {
            $async = $client.BeginConnect('127.0.0.1', $Port, $null, $null)
            if ($async.AsyncWaitHandle.WaitOne(2000) -and $client.Connected) {
                $client.EndConnect($async)
                return $true
            }
        } catch {
            # Server noch nicht bereit - weiter warten
        } finally {
            $client.Close()
        }
        Start-Sleep -Seconds 2
    }
    return $false
}

function Remove-OldItems([string]$Folder, [string]$Filter, [int]$Keep, [switch]$Directory) {
    $items = Get-ChildItem -LiteralPath $Folder -Filter $Filter -Directory:$Directory -File:(-not $Directory) |
             Sort-Object Name -Descending | Select-Object -Skip $Keep
    foreach ($item in $items) {
        Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction SilentlyContinue
        Write-Info "Entfernt: $($item.Name)"
    }
}

function Invoke-Rollback {
    Write-Step 'Stelle vorherigen Zustand wieder her ...'
    $ok = $true
    if (-not ($state.ServiceStopped -or $state.OldToolsMoved -or $state.NewToolsPlaced -or $state.ConfigChanged)) {
        Write-Info 'Es wurde noch nichts veraendert.'
        return $true
    }
    try {
        Stop-Service -Name $ServiceName -Force -ErrorAction Stop
    } catch {
        Write-Warning "Dienst konnte nicht gestoppt werden: $($_.Exception.Message)"
    }
    if ($state.ConfigChanged) {
        try {
            Copy-Item -LiteralPath $backup -Destination $ConfigFile -Force
            Write-Info 'svwsconfig.json aus der Sicherung wiederhergestellt.'
        } catch { $ok = $false; Write-Warning "Konfiguration NICHT wiederhergestellt: $($_.Exception.Message)" }
    }
    if ($state.NewToolsPlaced) {
        try {
            Remove-Item -LiteralPath $toolsDir -Recurse -Force
            Write-Info 'Neuer tools-Ordner entfernt.'
        } catch { $ok = $false; Write-Warning "Neuer tools-Ordner NICHT entfernt: $($_.Exception.Message)" }
    }
    if ($state.OldToolsMoved) {
        try {
            Rename-Item -LiteralPath $oldTools -NewName $ToolsDirName
            Write-Info 'Alter tools-Ordner zurueckbenannt.'
        } catch { $ok = $false; Write-Warning "Alter tools-Ordner NICHT zurueckbenannt: $($_.Exception.Message)" }
    }
    if ($state.WasRunning) {
        try {
            Start-Service -Name $ServiceName
            (Get-Service -Name $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds($ServiceTimeoutSec))
            Write-Info 'Dienst laeuft wieder.'
        } catch { $ok = $false; Write-Warning "Dienst NICHT wieder gestartet: $($_.Exception.Message)" }
    }
    return $ok
}

# ----------------------------- HAUPTPROGRAMM ------------------------------
$exitCode = 0
$transcriptStarted = $false
try {
    # 1. Vorpruefungen ------------------------------------------------------
    Write-Step '1/7 Vorpruefungen'
    if (-not (Test-Path -LiteralPath $Base -PathType Container)) {
        throw "SVWS-Ordner nicht gefunden: $Base"
    }
    if (-not (Test-Path -LiteralPath $LogDir)) {
        New-Item -ItemType Directory -Path $LogDir | Out-Null
    }
    $log = Join-Path $LogDir "tools-install-$stamp.log"
    Start-Transcript -Path $log | Out-Null
    $transcriptStarted = $true
    Write-Info "Protokoll: $log"

    if (-not (Test-Path -LiteralPath $ConfigFile -PathType Leaf)) {
        throw "Konfigurationsdatei nicht gefunden: $ConfigFile"
    }
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if (-not $service) { throw "Dienst '$ServiceName' nicht gefunden." }
    $state.WasRunning = ($service.Status -eq 'Running')
    Write-Info "Dienst '$ServiceName': $($service.Status)"

    $configText = Read-TextFile $ConfigFile
    try {
        $configObj = $configText | ConvertFrom-Json
    } catch {
        throw "svwsconfig.json ist schon vor der Aenderung kein gueltiges JSON: $($_.Exception.Message)"
    }
    $port = Get-HttpsPort $configObj
    Write-Info "HTTPS-Port laut Konfiguration: $port"

    # 2. Download und Pruefsumme -------------------------------------------
    Write-Step '2/7 Lade tools.zip herunter'
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    New-Item -ItemType Directory -Path $work -Force | Out-Null
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $zip -UseBasicParsing
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
    Write-Info ("Groesse: {0:N0} Bytes" -f (Get-Item -LiteralPath $zip).Length)
    Write-Info "SHA-256: $hash"
    if ($ExpectedSha256) {
        if ($hash -ne $ExpectedSha256.Trim()) {
            throw "Pruefsumme stimmt nicht. Erwartet: $ExpectedSha256"
        }
        Write-Info 'Pruefsumme stimmt.'
    } else {
        Write-Warning 'Es ist keine Pruefsumme hinterlegt - die Datei kann nicht verifiziert werden.'
        if ($Quiet) { throw 'Ohne hinterlegte Pruefsumme wird im Modus /quiet nicht installiert.' }
        if (-not (Confirm-Action 'Trotzdem fortfahren?')) { Stop-Cancelled 'Abbruch: Pruefsumme nicht bestaetigt.' }
    }

    # 3. In Zwischenordner entpacken und Inhalt pruefen --------------------
    Write-Step '3/7 Entpacke und pruefe den Inhalt'
    Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force
    $newTools = Join-Path $stage $ToolsDirName
    if (-not (Test-Path -LiteralPath $newTools -PathType Container)) {
        throw "tools.zip enthaelt keinen Ordner '$ToolsDirName' auf oberster Ebene."
    }
    $extra = @(Get-ChildItem -LiteralPath $stage | Where-Object { $_.Name -ne $ToolsDirName })
    if ($extra.Count -gt 0) {
        Write-Warning ('Weitere Eintraege im ZIP werden ignoriert: ' + (($extra | ForEach-Object { $_.Name }) -join ', '))
    }
    $fileCount = @(Get-ChildItem -LiteralPath $newTools -Recurse -File).Count
    if ($fileCount -eq 0) { throw "Der Ordner '$ToolsDirName' im ZIP ist leer." }
    Write-Info "$fileCount Dateien im neuen tools-Ordner."

    # 4. Rueckfrage vor dem Neustart ---------------------------------------
    Write-Step '4/7 Bestaetigung'
    if (-not $Quiet) {
        Write-Host '    Der SVWS-Server wird jetzt kurz gestoppt. Angemeldete Nutzer'
        Write-Host '    (SchILD-NRW 3, Web-Clients) verlieren ungespeicherte Eingaben.'
        if (-not (Confirm-Action 'Jetzt installieren und neu starten?')) { Stop-Cancelled 'Abbruch durch Benutzer.' }
    } else {
        Write-Info 'Modus /quiet - keine Rueckfrage.'
    }

    # 5. Dienst stoppen, Sicherung anlegen, tools austauschen --------------
    Write-Step '5/7 Stoppe Dienst und tausche den tools-Ordner aus'
    if ($state.WasRunning) {
        Stop-Service -Name $ServiceName -Force
        $state.ServiceStopped = $true
        (Get-Service -Name $ServiceName).WaitForStatus('Stopped', [TimeSpan]::FromSeconds($ServiceTimeoutSec))
        Write-Info 'Dienst gestoppt.'
    }
    Copy-Item -LiteralPath $ConfigFile -Destination $backup
    Write-Info "Sicherung: $backup"
    if (Test-Path -LiteralPath $toolsDir) {
        Rename-Item -LiteralPath $toolsDir -NewName (Split-Path $oldTools -Leaf)
        $state.OldToolsMoved = $true
        Write-Info "Alter tools-Ordner umbenannt in $(Split-Path $oldTools -Leaf)"
    }
    $state.NewToolsPlaced = $true
    Copy-Item -LiteralPath $newTools -Destination $toolsDir -Recurse
    Write-Info "Neue Tools installiert in $toolsDir"

    # 6. svwsconfig.json anpassen ------------------------------------------
    Write-Step '6/7 Trage AppsPath in svwsconfig.json ein'
    $jsonLiteral = ConvertTo-JsonString $toolsDir
    $newText = Set-AppsPath $configText $jsonLiteral
    Test-ConfigText $newText $toolsDir
    if ($newText -ceq $configText) {
        Write-Info 'AppsPath war bereits korrekt gesetzt.'
    } else {
        $state.ConfigChanged = $true
        Write-TextFile $ConfigFile $newText
        Write-Info "AppsPath = $toolsDir"
    }

    # 7. Dienst starten und Erreichbarkeit pruefen -------------------------
    Write-Step '7/7 Starte Dienst und pruefe Erreichbarkeit'
    Start-Service -Name $ServiceName
    (Get-Service -Name $ServiceName).WaitForStatus('Running', [TimeSpan]::FromSeconds($ServiceTimeoutSec))
    Write-Info 'Dienst laeuft.'
    if (-not (Wait-TcpPort $port $PortTimeoutSec)) {
        throw "Der Server antwortet nach $PortTimeoutSec Sekunden nicht auf Port $port."
    }
    Write-Info "Server antwortet auf Port $port."

    # Aufraeumen: alte Staende begrenzen
    Remove-OldItems -Folder $Base -Filter "$ToolsDirName.alt-*" -Keep $KeepOldTools -Directory
    Remove-OldItems -Folder (Split-Path $ConfigFile) -Filter 'svwsconfig.json.*.bak' -Keep $KeepConfigBackups

    if (-not $Quiet) {
        $url = if ($port -eq 443) { 'https://localhost/app/start' } else { "https://localhost:$port/app/start" }
        Write-Info "Oeffne $url"
        Start-Process $url
    }
}
catch [System.OperationCanceledException] {
    Write-Host ''
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    $exitCode = 2
}
catch {
    Write-Host ''
    Write-Host ('FEHLER: ' + $_.Exception.Message) -ForegroundColor Red
    if (Invoke-Rollback) { $exitCode = 1 } else { $exitCode = 3 }
}
finally {
    if (Test-Path -LiteralPath $work) {
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
}
exit $exitCode
